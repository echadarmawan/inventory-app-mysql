-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 04 Agu 2025 pada 09.25
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_inventory`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id_barang` char(10) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `id_kategori` char(10) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `harga_beli` decimal(10,0) NOT NULL,
  `harga_jual` decimal(10,0) NOT NULL,
  `stok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `id_kategori`, `satuan`, `harga_beli`, `harga_jual`, `stok`) VALUES
('BRG2507001', 'richeese nabati keju', 'KTGR0001', 'Pcs/Buah', 1000, 3000, 59),
('BRG2507002', 'Good Day Capuccino', 'KTGR0008', 'Pcs/Buah', 1900, 2500, 29),
('BRG2507003', 'Neko\'s Bathwater', 'KTGR0001', 'Kaleng', 500, 690000, 84),
('BRG2507004', 'Minyak Kayu Putih Cap Lang 60ML', 'KTGR0003', 'Botol', 1000, 23000, 50),
('BRG2507005', 'Panadol Biru', 'KTGR0003', 'Tablet/Strip', 10000, 12000, 25),
('BRG2507006', 'Es Mambo Kopi', 'KTGR0004', 'Pcs/Buah', 500, 1000, 20),
('BRG2507007', 'Es Batu', 'KTGR0004', 'Pcs/Buah', 550, 2000, 23),
('BRG2507112', 'Oreo Stroberi', 'KTGR0001', 'Pcs/Buah', 1000, 2000, 68),
('BRG2507113', 'Parfum', 'KTGR0006', 'Pcs/Buah', 6000, 10000, 80),
('BRG2507114', 'Sampo Sunsilk', 'KTGR0006', 'Lusin', 9999, 12000, 80),
('BRG2508001', 'coca cola botol 1 liter', 'KTGR0004', 'Liter', 8000, 11000, 14),
('BRG2508002', 'Luwak White Koffee', 'KTGR0008', 'Pcs/Buah', 1600, 2000, 0),
('BRG2508003', 'Indocafe', 'KTGR0008', 'Pcs/Buah', 1400, 2000, 0),
('BRG2508004', 'Susu Jahe', 'KTGR0008', 'Pcs/Buah', 1200, 2000, 0),
('BRG2508005', 'Kapal Api Special Mix', 'KTGR0008', 'Pcs/Buah', 1800, 2500, 0),
('BRG2508006', 'ABC Kopi Susu', 'KTGR0008', 'Pcs/Buah', 1700, 2500, 0),
('BRG2508007', 'Pop Ice Cokelat', 'KTGR0008', 'Pcs/Buah', 1400, 2000, 0),
('BRG2508008', 'Teh Tarik', 'KTGR0008', 'Pcs/Buah', 2300, 3000, 0),
('BRG2508009', 'Milo', 'KTGR0008', 'Pcs/Buah', 1900, 2500, 0),
('BRG2508010', 'Good Day Mocca', 'KTGR0008', 'Pcs/Buah', 1400, 2000, 0),
('BRG2508011', 'Luwak Ovalccino', 'KTGR0008', 'Pcs/Buah', 1000, 2000, 0),
('BRG2508012', 'Teh Jus Gula Batu', 'KTGR0008', 'Pcs/Buah', 400, 1000, 0),
('BRG2508013', 'Nutrisari Jeruk Nipis', 'KTGR0008', 'Pcs/Buah', 900, 1500, 0),
('BRG2508014', 'Dancow Vanilla', 'KTGR0008', 'Pcs/Buah', 4200, 5000, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pembelian`
--

CREATE TABLE `detail_pembelian` (
  `id_detail` int(11) NOT NULL,
  `id_pembelian` char(10) NOT NULL,
  `id_barang` char(10) NOT NULL,
  `kuantitas` int(11) NOT NULL,
  `subtotal` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `detail_pembelian`
--

INSERT INTO `detail_pembelian` (`id_detail`, `id_pembelian`, `id_barang`, `kuantitas`, `subtotal`) VALUES
(23, 'B134738001', 'BRG2507004', 25, 25000),
(24, 'B134738001', 'BRG2507005', 20, 200000),
(25, 'B134738001', 'BRG2507113', 20, 120000),
(26, 'B134738001', 'BRG2507114', 20, 199980),
(30, 'B135012001', 'BRG2507001', 50, 50000),
(31, 'B135012001', 'BRG2507002', 10, 500000),
(32, 'B135012001', 'BRG2507112', 40, 40000),
(33, 'B135012001', 'BRG2507113', 20, 120000),
(37, 'B141921001', 'BRG2507002', 10, 500000),
(38, 'B141921001', 'BRG2507003', 69, 34500),
(39, 'B141921001', 'BRG2507113', 30, 180000),
(40, 'B141921001', 'BRG2507114', 40, 399960),
(41, 'B134829001', 'BRG2507001', 15, 15000),
(42, 'B134829001', 'BRG2507004', 15, 15000),
(43, 'B134829001', 'BRG2507112', 20, 20000),
(44, 'B134829001', 'BRG2507114', 26, 146586),
(45, 'B162537001', 'BRG2507005', 10, 100000),
(47, 'B213407001', 'BRG2507002', 9, 450000),
(49, 'B001805001', 'BRG2507003', 20, 10000),
(50, 'B001805001', 'BRG2507112', 8, 8000),
(52, 'B005152001', 'BRG2507004', 11, 11000),
(53, 'B005152001', 'BRG2507113', 11, 66000),
(54, 'B194416001', 'BRG2508001', 20, 160000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_penjualan`
--

CREATE TABLE `detail_penjualan` (
  `id_detail` int(11) NOT NULL,
  `id_penjualan` char(10) NOT NULL,
  `id_barang` char(10) NOT NULL,
  `kuantitas` int(11) NOT NULL,
  `subtotal` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `detail_penjualan`
--

INSERT INTO `detail_penjualan` (`id_detail`, `id_penjualan`, `id_barang`, `kuantitas`, `subtotal`) VALUES
(18, 'J135246001', 'BRG2507001', 2, 6000),
(19, 'J135246001', 'BRG2507114', 1, 12000),
(21, 'J135536001', 'BRG2507001', 3, 9000),
(22, 'J135536001', 'BRG2507114', 3, 36000),
(24, 'J142624001', 'BRG2507003', 5, 3450000),
(25, 'J142624001', 'BRG2507007', 2, 4000),
(26, 'J191944001', 'BRG2507001', 1, 3000),
(27, 'J191944001', 'BRG2507004', 1, 23000),
(28, 'J191944001', 'BRG2507006', 10, 10000),
(29, 'J191944001', 'BRG2507007', 2, 4000),
(30, 'J191944001', 'BRG2507113', 1, 10000),
(31, 'J162720001', 'BRG2507006', 5, 5000),
(32, 'J162720001', 'BRG2507007', 10, 20000),
(33, 'J194619001', 'BRG2507006', 5, 5000),
(34, 'J194619001', 'BRG2508001', 1, 11000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` char(8) NOT NULL,
  `nama_kategori` varchar(20) NOT NULL,
  `is_deleted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`, `is_deleted`) VALUES
('KTGR0001', 'Makanan', 0),
('KTGR0002', 'Minuman Keras', 1),
('KTGR0003', 'Obat & Herbal', 0),
('KTGR0004', 'Minuman', 0),
('KTGR0005', 'ATK', 0),
('KTGR0006', 'Skincare', 0),
('KTGR0007', 'Rokok', 0),
('KTGR0008', 'Minuman Kemasan', 0),
('KTGR0009', 'Es Krim', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemasok`
--

CREATE TABLE `pemasok` (
  `id_pemasok` char(8) NOT NULL,
  `nama_pemasok` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `no_telepon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pemasok`
--

INSERT INTO `pemasok` (`id_pemasok`, `nama_pemasok`, `alamat`, `no_telepon`) VALUES
('SUPP0001', 'Toko Taman Sari', 'Jl. Tirtayasa Kecamatan Pinang', '08888888888888'),
('SUPP0002', 'Toko Adi', 'Jl. Tirtayasa', '077777777777'),
('SUPP0003', 'Toko Lukman Suryo', 'Jl. Tirtayasa', '087865367888'),
('SUPP0004', 'PT AICE', 'JL. Jalan', '086969696969');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian`
--

CREATE TABLE `pembelian` (
  `id_pembelian` char(10) NOT NULL,
  `id_pemasok` char(8) NOT NULL,
  `tanggal` date NOT NULL,
  `total` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `id_pemasok`, `tanggal`, `total`) VALUES
('B001805001', 'SUPP0001', '2025-07-29', 18000),
('B005152001', 'SUPP0003', '2025-07-29', 77000),
('B134738001', 'SUPP0001', '2025-07-23', 544980),
('B134829001', 'SUPP0004', '2025-07-24', 196586),
('B135012001', 'SUPP0001', '2025-07-23', 710000),
('B141921001', 'SUPP0002', '2025-07-23', 1114460),
('B162537001', 'SUPP0004', '2025-07-28', 100000),
('B194416001', 'SUPP0002', '2025-08-02', 160000),
('B213407001', 'SUPP0003', '2025-07-28', 450000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` char(8) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `username`, `password`, `role`) VALUES
('ADMIN001', 'admin', '$2a$12$v4jrJ1XTPljj5qGWLxrAHekk3pp./SGxTM1VtbV3njeHIXLubXb/i', 'Owner'),
('USER0001', 'staff', '$2a$12$Chnrt0igydKqiJR8vU3L7.GOUmjS7nGdXGsJrp1z/hfrspZnT.TWG', 'Staff'),
('USER0002', 'mama', '$2a$12$MA9jNcUJgh8bh8p1AVZZuejIib3Zr1R9EcIN0RKb4BcfFco..rKYi', 'Owner'),
('USER0003', 'sanfisa420', '$2a$12$GjZ9fgea.jUtsdoVVvD/wef1QNBfiDG8cls9EV6Z7dOwW8OsFplLe', 'Staff'),
('USER0004', 'papa', '$2a$12$wVKQiRoLcxOH9ddeJB1v..exM7ozfiXqD7qSBi3CjUqUDgL3IBiNK', 'Staff'),
('USER0005', 'keshia', '$2a$12$oD.hwB2UDbOV4AEIlDKnAuvYs.pNPsV2hAssEZkIKXiQhvzPGTjka', 'Staff');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` char(10) NOT NULL,
  `id_pengguna` char(8) NOT NULL,
  `tanggal` date NOT NULL,
  `total` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `id_pengguna`, `tanggal`, `total`) VALUES
('J135246001', 'ADMIN001', '2025-07-23', 18000),
('J135536001', 'ADMIN001', '2025-07-23', 45000),
('J142624001', 'USER0001', '2025-07-23', 3454000),
('J162720001', 'USER0004', '2025-07-28', 25000),
('J191944001', 'USER0003', '2025-07-24', 50000),
('J194619001', 'ADMIN001', '2025-08-02', 16000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `stok_keluar`
--

CREATE TABLE `stok_keluar` (
  `id_stok_keluar` char(10) NOT NULL,
  `id_barang` char(10) NOT NULL,
  `id_pengguna` char(8) NOT NULL,
  `tanggal` date NOT NULL,
  `kuantitas` int(11) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `stok_keluar`
--

INSERT INTO `stok_keluar` (`id_stok_keluar`, `id_barang`, `id_pengguna`, `tanggal`, `kuantitas`, `keterangan`) VALUES
('K135407001', 'BRG2507005', 'ADMIN001', '2025-07-23', 5, 'Kadaluarsa'),
('K135427001', 'BRG2507114', 'ADMIN001', '2025-07-23', 2, 'Digunakan sendiri'),
('K194804001', 'BRG2508001', 'ADMIN001', '2025-08-02', 5, 'kadaluarsa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `stok_masuk`
--

CREATE TABLE `stok_masuk` (
  `id_stok_masuk` char(10) NOT NULL,
  `id_barang` char(10) NOT NULL,
  `id_pengguna` char(8) NOT NULL,
  `tanggal` date NOT NULL,
  `kuantitas` int(11) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `stok_masuk`
--

INSERT INTO `stok_masuk` (`id_stok_masuk`, `id_barang`, `id_pengguna`, `tanggal`, `kuantitas`, `keterangan`) VALUES
('M135124001', 'BRG2507007', 'ADMIN001', '2025-07-23', 10, 'Buat sendiri'),
('M135142001', 'BRG2507006', 'ADMIN001', '2025-07-23', 40, 'Buat sendiri'),
('M135458001', 'BRG2507007', 'ADMIN001', '2025-07-24', 12, 'Bikin sendiri'),
('M162644001', 'BRG2507007', 'USER0004', '2025-07-28', 15, 'Bikin sendiri');

-- --------------------------------------------------------

--
-- Struktur dari tabel `temp_pembelian`
--

CREATE TABLE `temp_pembelian` (
  `id_detail` int(11) NOT NULL,
  `id_barang` char(10) NOT NULL,
  `kuantitas` int(11) NOT NULL,
  `subtotal` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `temp_penjualan`
--

CREATE TABLE `temp_penjualan` (
  `id_detail` int(11) NOT NULL,
  `id_barang` char(10) NOT NULL,
  `kuantitas` int(11) NOT NULL,
  `subtotal` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`),
  ADD KEY `fk_kategori_barang` (`id_kategori`);

--
-- Indeks untuk tabel `detail_pembelian`
--
ALTER TABLE `detail_pembelian`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `fk_barang_detpembelian` (`id_barang`),
  ADD KEY `fk_pembelian_detpembelian` (`id_pembelian`);

--
-- Indeks untuk tabel `detail_penjualan`
--
ALTER TABLE `detail_penjualan`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `fk_barang_detpenjualan` (`id_barang`),
  ADD KEY `fk_penjualan_detpenjualan` (`id_penjualan`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `pemasok`
--
ALTER TABLE `pemasok`
  ADD PRIMARY KEY (`id_pemasok`);

--
-- Indeks untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`),
  ADD KEY `fk_pemasok_pembelian` (`id_pemasok`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indeks untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`),
  ADD KEY `fk_pengguna_penjualan` (`id_pengguna`);

--
-- Indeks untuk tabel `stok_keluar`
--
ALTER TABLE `stok_keluar`
  ADD PRIMARY KEY (`id_stok_keluar`),
  ADD KEY `fk_pengguna_stokkeluar` (`id_pengguna`),
  ADD KEY `fk_barang_stokkeluar` (`id_barang`);

--
-- Indeks untuk tabel `stok_masuk`
--
ALTER TABLE `stok_masuk`
  ADD PRIMARY KEY (`id_stok_masuk`),
  ADD KEY `fk_pengguna_stokmasuk` (`id_pengguna`),
  ADD KEY `fk_barang_stokmasuk` (`id_barang`);

--
-- Indeks untuk tabel `temp_pembelian`
--
ALTER TABLE `temp_pembelian`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `fk_barang_temppembelian` (`id_barang`);

--
-- Indeks untuk tabel `temp_penjualan`
--
ALTER TABLE `temp_penjualan`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `fk_barang_temppenjualan` (`id_barang`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `detail_pembelian`
--
ALTER TABLE `detail_pembelian`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT untuk tabel `detail_penjualan`
--
ALTER TABLE `detail_penjualan`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT untuk tabel `temp_pembelian`
--
ALTER TABLE `temp_pembelian`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `temp_penjualan`
--
ALTER TABLE `temp_penjualan`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `fk_kategori_barang` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `detail_pembelian`
--
ALTER TABLE `detail_pembelian`
  ADD CONSTRAINT `fk_barang_detpembelian` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pembelian_detpembelian` FOREIGN KEY (`id_pembelian`) REFERENCES `pembelian` (`id_pembelian`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `detail_penjualan`
--
ALTER TABLE `detail_penjualan`
  ADD CONSTRAINT `fk_barang_detpenjualan` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_penjualan_detpenjualan` FOREIGN KEY (`id_penjualan`) REFERENCES `penjualan` (`id_penjualan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD CONSTRAINT `fk_pemasok_pembelian` FOREIGN KEY (`id_pemasok`) REFERENCES `pemasok` (`id_pemasok`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `fk_pengguna_penjualan` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `stok_keluar`
--
ALTER TABLE `stok_keluar`
  ADD CONSTRAINT `fk_barang_stokkeluar` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pengguna_stokkeluar` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `stok_masuk`
--
ALTER TABLE `stok_masuk`
  ADD CONSTRAINT `fk_barang_stokmasuk` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pengguna_stokmasuk` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `temp_pembelian`
--
ALTER TABLE `temp_pembelian`
  ADD CONSTRAINT `fk_barang_temppembelian` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `temp_penjualan`
--
ALTER TABLE `temp_penjualan`
  ADD CONSTRAINT `fk_barang_temppenjualan` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
